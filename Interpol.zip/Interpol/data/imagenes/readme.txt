Imagenes sacadas de:

Microsoft Office
http://www.columbia.edu/cu/news/01/04/images/asianAlumni.jpg
http://www.karlitoswayaccordions.com/images/5-30/latino2_small.jpg
http://198.214.252.201/~rsetser/00351FE2-0118C717.0/magnifying-glass.gif
http://unac.atomicmotion.com/uploads/footprints.jpg
http://www.peoriacounty.org/images/countyBoard/moneybag.jpg
http://p.vtourist.com/498319-Travel_Picture-Barranquilla.jpg
http://www.oceandots.com/atlantic/san-andres/m/006-14568.jpg
http://www.col.ops-oms.org/desastres/2004/galeras/img/foto06.jpg
http://www.flickr.com/photo_zoom.gne?id=284202941&size=l
http://www.studylanguages.org/images/milan/milan1.jpg
http://www.studylanguages.org/images/chile/santiago3.jpg
http://canadianwinter.ca/bc/images/gallery_images/vancouver_downtown_at_night2.jpg
http://www.stonehill.edu/foreign_languages/munich.jpg
http://www.theodora.com/wfb/photos/brazil/ibirapuera_park_sao_paulo_brazil_photo_gov_tourist_ministry.jpg
http://www.visitortips.com/images/gallery/destinations/usa/texas/dallas/fullsize/dallas8.jpg
http://www.top-city-photos.com/images/manchester-canal.JPG
http://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Jama_Masjid_2.JPG/800px-Jama_Masjid_2.JPG
http://www.liv.ac.uk/~sdb/Egypt/Temples/Images/03-CD16-Cairo-night.jpg
http://www.jccv.org.au/images/melbourne.jpg
http://evolucion.fcien.edu.uy/Montevideo.jpg
http://users.isr.ist.utl.pt/~reza/portugal/porto.JPG
http://www.castellitoscani.com/photos/montecarlo_aerea.jpg
http://www.twip.org/city-list-all-sp-0-0.html
http://www.fotosbogota.galeon.com/
http://www.cartagenadeindias.com.co/
http://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/The_Pentagon_US_Department_of_Defense_building.jpg/225px-The_Pentagon_US_Department_of_Defense_building.jpg
http://www.terra.es/personal/rod.diaz/america.htm
http://www.publispain.com/viajes/miami/galeriasdefotos.htm
http://images.google.com.co/
http://stonek.com/banco/resultado2.php?recordID=http://stonek.com/_FOTOGRAFOS/riolir/riolir_Puente2.jpg
http://www.caminandosinrumbo.com/eu/dc/index.htm
http://foro.univision.com/univision/board/message?board.id=montreal&message.id=51
http://www.fotomaf.com/albums/BangkokTaipei/TeatroNacionalTaiwan.jpg
http://www.travel-images.com/taiwan.html
http://www.publispain.com/viajes/los-angeles/fotos-los-angeles.htm
http://www.argentinaturistica.com/informa/basifotos.htm
http://groups.msn.com/CiudaddeMexico/shoebox.msnw

