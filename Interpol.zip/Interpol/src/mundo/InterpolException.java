/*
 *
 */

package mundo;

/**
 *
 * @author Jorge A. Arévalo A. - Docente Universidad Piloto de Colombia
 */
public class InterpolException extends Exception {
    /**
     * Constructor por parámetros.
     * @param mensaje Mensaje a mostrar
     */
    public InterpolException(String mensaje) {
        super(mensaje);
    }

}
