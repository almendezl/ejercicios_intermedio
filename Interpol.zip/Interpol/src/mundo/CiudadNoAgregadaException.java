/*
 *
 */

package mundo;

/**
 *
 * @author Jorge A. Arévalo A. - Docente Universidad Piloto de Colombia
 */
public class CiudadNoAgregadaException extends Exception {
    /**
     * Constructor por parámetros.
     * @param mensaje Mensaje a mostrar
     */
    public CiudadNoAgregadaException(String mensaje) {
        super(mensaje);
    }

}
